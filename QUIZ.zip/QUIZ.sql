create table Institute(
ID int Primary Key auto_increment,
NAME varchar(50) NOT NULL,
EMAIL varchar(50) NOT NULL,
USERNAME varchar(50) UNIQUE NOT NULL,
PWD varchar(50) NOT NULL);

select * from Institute;
truncate institute;
insert into Institute (Name) values ("NMS"),("MUJ"); 
Insert into Institute values ('NMS','nms@','nm2','pass');


create table Student(
NAME varchar(50) NOT NULL,
EMAIL varchar(50) NOT NULL,
INSID int NOT NULL,
USERNAME varchar(50) Primary Key NOT NULL,
PWD varchar(50) NOT NULL);

select * from student;
drop table Institute;
truncate student;
Insert into Student values ('fajd','hhhvh','2','hkjsjf','nhsv');

create table contactus(
NAME varchar(50) NOT NULL,
EMAIL varchar(50) NOT NULL,
MESSAGE TEXT);

select * from contactus;
truncate contactus;

create table exam(
EID int auto_increment PRIMARY KEY,
INS_ID int NOT NULL,
NAME varchar(50) NOT NULL);



select * from exam;

delete from exam where EID=2;

create table question_table(
E_ID int NOT NULL references exam(EID),
QID INT NOT NULL auto_increment PRIMARY KEY,
QNAME TEXT NOT NULL,
OPTION1 TEXT NOT NULL,
OPTION2 TEXT NOT NULL,
OPTION3 TEXT NOT NULL,
OPTION4 TEXT NOT NULL,
ANSWER TEXT NOT NULL);

select * from question_table;
truncate exam;
select * from student s inner join institute i on s.INSID=i.ID;

select count(QID) as cnt from question_table where E_ID = 1;

select eid,name, ifnull(q.cnt,0) from exam e left join (select e_id, count(*) as cnt from question_table group by e_id) q on  q.e_id=e.eid where INS_ID=1;


select e_id, count(*) from question_table group by e_id;


insert into question_table (E_ID ,
QNAME ,
OPTION1 ,
OPTION2 ,
OPTION3 ,
OPTION4 ,
ANSWER)
values (1,'What is 1+9','10','2','6','3','10');

create table score_table (
S_USENAME varchar(50)  NOT NULL references student(USERNAME),
S_EID int NOT NULL references exam(EID),
SCORE int NOT NULL);

select * from question_table;
select * from score_table;
truncate score_table;
truncate question_table;

delete from score_table where etime is null;

select s.name,e.name,st.score,st.etime  from student s,score_table st,exam e where s.username=st.S_USENAME and e.eid=st.S_EID;

