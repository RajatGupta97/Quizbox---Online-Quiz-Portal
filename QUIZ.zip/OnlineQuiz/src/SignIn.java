import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SignIn")
public class SignIn extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(true);
		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/OnlineQuiz", "root",
					"underground12");

			String user = request.getParameter("user");
			String pass = request.getParameter("pass");
			String usertype = request.getParameter("usertype");
			Statement stmt = con.createStatement();
			String sql = "";
			if (usertype.equals("Student")) {	
				sql = "select s.name,s.email,s.insid,i.name as `iname` from student s inner join institute i on s.INSID=i.ID where s.USERNAME = '" + user + "' and s.PWD = '" + pass + "'";
				out.println(sql);
				ResultSet rs = stmt.executeQuery(sql);

				if (rs.next()) {
					String name = rs.getString("NAME");
					String email = rs.getString("EMAIL");
					String iname = rs.getString("iname");
					String insid = rs.getString("insid");
					session.setAttribute("name", name);
					session.setAttribute("email", email);
					session.setAttribute("iname", iname);
					session.setAttribute("user", user);
					session.setAttribute("insid",insid);

					response.sendRedirect("StudentPage.jsp");
					
				} else {
					out.println(
							"<html><body><script language='javascript'>alert('Error'); location.href='index.jsp';</script></body></html>");

				}
			} else if (usertype.equals("Institute")) {
				sql = "select * from institute where USERNAME = '" + user + "' and PWD = '" + pass + "'";
				
				ResultSet rs = stmt.executeQuery(sql);

				if (rs.next()) {
					String name = rs.getString("NAME");
					String email = rs.getString("EMAIL");
					String id = rs.getString("ID");
					session.setAttribute("name", name);
					session.setAttribute("email", email);
					session.setAttribute("id", id);
					session.setAttribute("user", user);

					response.sendRedirect("InstitutePage.jsp");
				} else {
					out.println(
							"<html><body><script language='javascript'>alert('Error'); location.href='index.jsp';</script></body></html>");
				}
			}

			stmt.close();
			con.close();

		} catch (SQLException exception) {
			out.println("Error");
			exception.printStackTrace();
		}
		out.close();
	}
}
