
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.*;

/**
 * Servlet implementation class Register
 */
@WebServlet("/SignUpStudent")
public class SignUpStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(true);
		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/OnlineQuiz", "root",
					"underground12");

			String name = request.getParameter("SName");
			String email = request.getParameter("SEmail");
			String ins = request.getParameter("Institute");
			String user = request.getParameter("User");
			String pass = request.getParameter("Pass");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from Student where username='"+user+"'");
			if(rs.next())
			{
				session.setAttribute("SignupError", "Student already exists");
				response.sendRedirect("index.jsp");
				return;
			}else{
			String sql = "Insert into Student values ('" + name + "','" + email + "','" + ins + "','" + user + "','"
					+ pass + "')";
			// out.println(sql);
			stmt.executeUpdate(sql);
			// out.println("Success");
			out.println(
					"<html><body><script language='javascript'>alert('Sign Up Complete'); location.href='index.jsp';</script></body></html>");
			}
			stmt.close();
			con.close();

		} catch (SQLException exception) {
			out.println(
					"<html><body><script language='javascript'>alert('User Already Signed Up or Details Incorrect'); location.href='index.jsp';</script></body></html>");
		}
		out.close();
	}

}
