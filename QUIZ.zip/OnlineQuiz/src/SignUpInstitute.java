
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SignUpInstitute
 */
@WebServlet("/SignUpInstitute")
public class SignUpInstitute extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/OnlineQuiz", "root",
					"underground12");

			String name = request.getParameter("IName");
			String email = request.getParameter("IEmail");
			String user = request.getParameter("IUser");
			String pass = request.getParameter("IPass");
			Statement stmt = con.createStatement();
			String sql = "Insert into Institute (name,email,username,pwd) values ('" + name + "','" + email + "','"
					+ user + "','" + pass + "')";
			// out.println(sql);
			stmt.executeUpdate(sql);
			// out.println("Success");
			out.println(
					"<html><body><script language='javascript'>alert('Sign Up Complete'); location.href='index.jsp';</script></body></html>");
			stmt.close();
			con.close();

		} catch (SQLException exception) {
			out.println(
					"<html><body><script language='javascript'>alert('User Already Signed Up or Details Incorrect'); location.href='index.jsp';</script></body></html>");
		}
		out.close();
	}

}
