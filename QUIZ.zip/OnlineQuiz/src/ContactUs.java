
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ContactUs")
public class ContactUs extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/OnlineQuiz", "root",
					"underground12");

			String name = request.getParameter("name");
			String email = request.getParameter("email");
			String msg = request.getParameter("message");
			Statement stmt = con.createStatement();
			String sql = "Insert into contactus values ('" + name + "','" + email + "','" + msg + "')";
			stmt.executeUpdate(sql);
			response.sendRedirect("index.jsp");

			stmt.close();
			con.close();

		} catch (SQLException exception) {
			out.println("Error");
			exception.printStackTrace();
		}
		out.close();
	}

}
